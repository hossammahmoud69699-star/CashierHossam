package com.hossam.cashier;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;

public class MainActivity extends Activity {
    private WebView webView;
    private StoreDb storeDb;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        storeDb = new StoreDb();
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeDbBridge(), "NativeDB");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeDbBridge {
        @JavascriptInterface public String getData() {
            SQLiteDatabase db = storeDb.getReadableDatabase();
            try (Cursor c = db.rawQuery("SELECT payload FROM app_state WHERE id=1", null)) {
                return c.moveToFirst() ? c.getString(0) : "";
            }
        }
        @JavascriptInterface public boolean saveData(String payload) {
            try {
                ContentValues values = new ContentValues();
                values.put("id", 1);
                values.put("payload", payload);
                storeDb.getWritableDatabase().insertWithOnConflict("app_state", null, values, SQLiteDatabase.CONFLICT_REPLACE);
                return true;
            } catch (Exception e) { return false; }
        }
    }

    private class StoreDb extends SQLiteOpenHelper {
        StoreDb() { super(MainActivity.this, "cashier_hossam.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE app_state (id INTEGER PRIMARY KEY, payload TEXT NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
